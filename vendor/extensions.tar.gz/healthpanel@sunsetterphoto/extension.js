// HealthPanel for GNOME Shell — the panel-indicator port of the Plasma 6 widget.
//
// Same job, same data, same layout vocabulary: a live system column, a battery
// column and a controls column, each section reorderable and hideable. What
// changes is the shell around it — a PanelMenu.Button in the top bar instead of
// a plasmoid, St widgets instead of QML, GSettings instead of
// Plasmoid.configuration.
//
// The parts that are pure logic are NOT rewritten: lib/sysparse.js and
// lib/layoutmeta.js are generated verbatim from the widget's own JS by
// tools/sync-lib.sh, so both desktops parse /proc identically and an upstream
// fix reaches this extension by re-running one script.

import Clutter from 'gi://Clutter';
import GLib from 'gi://GLib';
import Gio from 'gi://Gio';
import GObject from 'gi://GObject';
import St from 'gi://St';

import {Extension} from 'resource:///org/gnome/shell/extensions/extension.js';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PanelMenu from 'resource:///org/gnome/shell/ui/panelMenu.js';
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js';
import * as Slider from 'resource:///org/gnome/shell/ui/slider.js';

import {Collector} from './lib/collector.js';
import {Controls} from './lib/controls.js';
import * as LayoutMeta from './lib/layoutmeta.js';
import * as PanelMeta from './lib/panelmeta.js';
import * as PanelText from './lib/paneltext.js';
import * as I18n from './lib/i18n.js';
import * as Bat from './lib/battery.js';
import {MetricRow, MeterBar, valueColor} from './lib/widgets.js';

const PROFILE_LABELS = {
    'performance': 'Performance',
    'balanced': 'Balanced',
    'power-saver': 'Power Saver',
};

const PROFILE_ICONS = {
    'performance': 'power-profile-performance-symbolic',
    'balanced': 'power-profile-balanced-symbolic',
    'power-saver': 'power-profile-power-saver-symbolic',
};

function gb(v) {
    return `${v.toFixed(1)} GB`;
}

const HealthPanelIndicator = GObject.registerClass(
class HealthPanelIndicator extends PanelMenu.Button {
    _init(extension) {
        super._init(0.5, 'HealthPanel');
        this._ext = extension;
        this._settings = extension.getSettings();
        this._rows = new Map();

        this._lang = I18n.resolve(this._settings.get_string('language'));
        this._tr = s => I18n.tr(this._lang, s);

        // The collector must exist before the menu is built: the power-mode
        // section asks it which profiles the daemon offers.
        this._collector = new Collector(
            GLib.build_filenamev([extension.path, 'probes']));
        this._controls = new Controls();
        this._controlsId = this._controls.connect('changed', () => this._syncControls());

        this._buildPanelButton();
        this._buildMenu();

        this._collector.connect('changed', () => this._refresh());
        this._collector.start(
            this._settings.get_int('refresh-seconds'),
            this._settings.get_int('idle-refresh-seconds'));

        // Sampling at the fast rate is only worth it while somebody is looking.
        this.menu.connect('open-state-changed', (_m, open) => {
            this._collector.setActive(open);
            if (open)
                this._controls.refreshScreen();
        });

        this._settingsIds = [
            this._settings.connect('changed::refresh-seconds', () => this._applyRates()),
            this._settings.connect('changed::idle-refresh-seconds', () => this._applyRates()),
            ...['cpu', 'gpu', 'vram', 'ram', 'disk', 'net'].map(k =>
                this._settings.connect(`changed::${k}-style`, () => this._rebuildSystem())),
            this._settings.connect('changed::system-order', () => this._rebuildSystem()),
            this._settings.connect('changed::battery-order', () => this._rebuildBattery()),
            this._settings.connect('changed::language', () => this._applyLanguage()),
            this._settings.connect('changed::show-panel-text', () => this._refresh()),
            this._settings.connect('changed::panel-layout', () => this._refresh()),
        ];
    }

    destroy() {
        for (const id of this._settingsIds ?? [])
            this._settings.disconnect(id);
        this._settingsIds = [];
        this._collector?.stop();
        this._collector = null;
        if (this._controlsId)
            this._controls.disconnect(this._controlsId);
        this._controlsId = 0;
        this._controls?.destroy();
        this._controls = null;
        super.destroy();
    }

    _applyRates() {
        this._collector.setRates(
            this._settings.get_int('refresh-seconds'),
            this._settings.get_int('idle-refresh-seconds'));
    }

    _applyLanguage() {
        this._lang = I18n.resolve(this._settings.get_string('language'));
        this._rebuildSystem();
        this._rebuildBattery();
        this._refresh();
    }

    // ---- panel button -------------------------------------------------------

    _buildPanelButton() {
        // Der Inhalt haengt an der Einstellung und wird in _refreshPanel()
        // gebaut; hier steht nur der Kasten, der ihn aufnimmt.
        this._panelBox = new St.BoxLayout({style_class: 'panel-status-menu-box'});
        this._panelEntries = [];
        this._panelKey = '';
        this.add_child(this._panelBox);
    }

    /**
     * Die Leiste aus der Einstellung aufbauen — Symbole und ihre Werte.
     *
     * Die Aktoren werden nur neu erzeugt, wenn sich der Aufbau aendert, nicht
     * bei jedem Messtakt: das laeuft im Compositor-Prozess, und ein Neuaufbau
     * im Sekundentakt kostet dort Bilder.
     */
    _rebuildPanel() {
        const raw = this._settings.get_string('panel-layout');
        if (raw === this._panelKey)
            return;
        this._panelKey = raw;

        this._panelBox.destroy_all_children();
        this._panelEntries = [];
        for (const entry of PanelMeta.parseLayout(raw)) {
            const row = new St.BoxLayout({style_class: 'healthpanel-panel-entry'});
            // icon !== false: ein Eintrag darf ausdruecklich nur Text sein.
            const icon = entry.icon === false ? null : new St.Icon({
                style_class: 'system-status-icon',
            });
            if (icon)
                row.add_child(icon);
            const label = new St.Label({
                text: '',
                style_class: 'healthpanel-panel-label',
                y_align: Clutter.ActorAlign.CENTER,
            });
            row.add_child(label);
            this._panelBox.add_child(row);
            this._panelEntries.push({entry, icon, label});
        }
    }

    _refreshPanel(battery, system) {
        this._rebuildPanel();
        // Der alte Schalter gilt nur noch fuer die Voreinstellung: wer sich
        // eigene Symbole zusammenstellt, hat den Text ja gerade gewaehlt, und
        // unbeschriftete Symbole waeren das Gegenteil des Gewuenschten.
        const single = this._panelEntries.length === 1
            && this._panelEntries[0].entry.type === 'battery';
        const allowText = !single || this._settings.get_boolean('show-panel-text');

        for (const {entry, icon, label} of this._panelEntries) {
            if (icon)
                icon.icon_name = PanelText.iconFor(entry.type, battery, system);
            label.text = allowText ? PanelText.textFor(entry, battery, system) : '';
            label.visible = label.text !== '';
        }
    }

    // Die Schwellen des Akkusymbols stehen jetzt in lib/paneltext.js — an EINER
    // Stelle, zusammen mit den uebrigen Werten der Leiste, und dort nachprüfbar.

    // ---- menu ---------------------------------------------------------------

    _buildMenu() {
        const item = new PopupMenu.PopupBaseMenuItem({
            reactive: false,
            can_focus: false,
            style_class: 'healthpanel-popup',
        });

        const columns = new St.BoxLayout({vertical: false, x_expand: true});
        this._systemBox = this._column(this._tr('System'));
        this._batteryBox = this._column(this._tr('Battery'));
        this._controlBox = this._column(this._tr('Controls'));

        const order = LayoutMeta.parseOrder(
            this._settings.get_string('column-order'), LayoutMeta.columns());
        const byId = {
            system: this._systemBox,
            battery: this._batteryBox,
            controls: this._controlBox,
        };
        for (const {id, v} of order) {
            if (v && byId[id])
                columns.add_child(byId[id].outer);
        }

        item.add_child(columns);
        this.menu.addMenuItem(item);

        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
        const prefs = new PopupMenu.PopupMenuItem(this._tr('Settings…'));
        prefs.connect('activate', () => this._ext.openPreferences());
        this.menu.addMenuItem(prefs);

        this._rebuildSystem();
        this._rebuildBattery();
        this._buildControls();

        // _rebuildSystem/_rebuildBattery each end in _refresh(), which touches
        // both columns — only safe once both exist.
        this._built = true;
        this._refresh();
    }

    _column(title) {
        const outer = new St.BoxLayout({
            vertical: true,
            style_class: 'healthpanel-column',
            x_expand: true,
        });
        outer.add_child(new St.Label({
            text: title,
            style_class: 'healthpanel-column-title',
        }));
        const content = new St.BoxLayout({vertical: true, x_expand: true});
        outer.add_child(content);
        return {outer, content};
    }

    _rebuildSystem() {
        const box = this._systemBox.content;
        box.destroy_all_children();
        this._rows.clear();

        const order = LayoutMeta.parseOrder(
            this._settings.get_string('system-order'), LayoutMeta.systemSections());

        for (const {id, v} of order) {
            if (!v)
                continue;
            if (id === 'powerMode') {
                this._profileBox = new St.BoxLayout({
                    style_class: 'healthpanel-profiles',
                    x_expand: true,
                });
                box.add_child(this._profileBox);
                this._buildProfileButtons();
                continue;
            }
            for (const [rowId, label] of this._rowsFor(id)) {
                const row = new MetricRow(this._tr(label), this._styleFor(rowId));
                box.add_child(row);
                this._rows.set(rowId, row);
            }
        }
        this._refresh();
    }

    // Die Hauptmesswerte haben je einen eigenen Stil, wie im Plasmoid. Die
    // Nebenwerte (Temperatur, Leistung, Durchsatz) bleiben Balken: ein
    // Sparkline fuer eine einzelne Temperatur traegt keine Information, die der
    // Zahl daneben fehlt.
    _styleFor(rowId) {
        const key = {
            cpuPct: 'cpu-style', gpuBusy: 'gpu-style', vram: 'vram-style',
            ram: 'ram-style', disk: 'disk-style', net: 'net-style',
        }[rowId];
        return key ? this._settings.get_string(key) : 'bar';
    }

    // One layout section can carry several readings (CPU load + temperature…).
    _rowsFor(sectionId) {
        switch (sectionId) {
        case 'cpu':
            return [['cpuPct', 'CPU'], ['cpuTemp', 'Temperature'], ['cpuPower', 'Power']];
        case 'gpu':
            return [['gpuBusy', 'GPU'], ['vram', 'VRAM'], ['gpuTemp', 'GPU temperature']];
        case 'ram':
            return [['ram', 'RAM'], ['swap', 'Swap']];
        case 'disk':
            return [['disk', 'Disk'], ['diskIo', 'Disk I/O'], ['diskTemp', 'Disk temperature']];
        case 'fans':
            return [['fans', 'Fans']];
        case 'net':
            return [['net', 'Network']];
        default:
            return [];
        }
    }

    _buildProfileButtons() {
        this._profileBox.destroy_all_children();
        if (!this._collector?.hasProfiles) {
            this._profileBox.hide();
            return;
        }
        this._profileBox.show();
        this._profileButtons = new Map();
        for (const name of this._collector.profile.available) {
            const btn = new St.Button({
                style_class: 'healthpanel-profile-button',
                child: new St.Icon({
                    icon_name: PROFILE_ICONS[name] ?? 'preferences-system-symbolic',
                    icon_size: 16,
                }),
                can_focus: true,
                toggle_mode: false,
            });
            btn.set_accessible_name(PROFILE_LABELS[name] ?? name);
            btn.connect('clicked', () => this._collector.setPowerProfile(name));
            this._profileBox.add_child(btn);
            this._profileButtons.set(name, btn);
        }
    }

    _rebuildBattery() {
        const box = this._batteryBox.content;
        box.destroy_all_children();
        this._batRows = new Map();

        this._chargeBar = new MeterBar({height: 12, x_expand: true});
        this._chargeLabel = new St.Label({style_class: 'healthpanel-charge-label'});
        box.add_child(this._chargeLabel);
        box.add_child(this._chargeBar);

        const order = LayoutMeta.parseOrder(
            this._settings.get_string('battery-order'), LayoutMeta.batteryBlocks());
        for (const {id, v} of order) {
            if (!v)
                continue;
            const row = new St.BoxLayout({style_class: 'healthpanel-kv'});
            const key = new St.Label({
                text: this._tr(this._batteryLabel(id)),
                style_class: 'healthpanel-kv-key',
                x_expand: true,
            });
            const val = new St.Label({text: '—', style_class: 'healthpanel-kv-value'});
            row.add_child(key);
            row.add_child(val);
            box.add_child(row);
            this._batRows.set(id, {row, val});
        }
        this._refresh();
    }

    _batteryLabel(id) {
        return {
            cycles: 'Cycles',
            capacity: 'Capacity',
            status: 'Status',
            power: 'Power draw',
            voltage: 'Voltage',
            time: 'Remaining time',
            serial: 'Serial',
            chargeLimit: 'Charge limit',
        }[id] ?? id;
    }

    _buildControls() {
        const box = this._controlBox.content;
        box.destroy_all_children();
        this._controlRows = {};

        // Sliders first, launchers last — the same order as the Plasma widget.
        // Each row only exists when its backend answered; a machine without a
        // keyboard backlight must not grow a dead slider (see lib/controls.js).
        const slider = (key, label, iconName, getPercent, setPercent) => {
            const row = new St.BoxLayout({style_class: 'healthpanel-control-row'});
            row.add_child(new St.Icon({icon_name: iconName, icon_size: 16}));
            const s = new Slider.Slider(getPercent() / 100);
            s.x_expand = true;
            // 'notify::value' also fires when we set it ourselves, which would
            // echo the backend's own value straight back at it.
            s.connect('drag-end', () => setPercent(s.value * 100));
            s.connect('scroll-event', () => setPercent(s.value * 100));
            row.add_child(s);
            const value = new St.Label({
                text: `${Math.round(getPercent())} %`,
                style_class: 'healthpanel-kv-value',
            });
            row.add_child(value);
            box.add_child(row);
            this._controlRows[key] = {row, slider: s, value};
        };

        const c = this._controls;
        if (c.screen.available) {
            slider('screen', 'Screen', 'display-brightness-symbolic',
                   () => c.screen.percent, p => c.setScreenPercent(p));
        }
        if (c.keyboard.available) {
            slider('keyboard', 'Keyboard', 'keyboard-brightness-symbolic',
                   () => c.keyboard.percent, p => c.setKeyboardPercent(p));
        }
        if (c.volume.available) {
            slider('volume', 'Volume', 'audio-volume-high-symbolic',
                   () => c.volume.percent, p => c.setVolumePercent(p));
            const mute = new St.Button({
                style_class: 'healthpanel-icon-button',
                child: new St.Icon({icon_name: 'audio-volume-high-symbolic', icon_size: 16}),
            });
            mute.connect('clicked', () => c.toggleMuted());
            this._controlRows.volume.row.add_child(mute);
            this._controlRows.mute = {row: mute};
        }

        const inhibit = new St.Button({
            style_class: 'healthpanel-control-button',
            child: new St.Label({text: this._tr('Prevent standby & lock')}),
            x_expand: true,
        });
        inhibit.connect('clicked', () => c.setInhibited(!c.inhibited));
        box.add_child(inhibit);
        this._controlRows.inhibit = {row: inhibit, value: null};

        const add = (label, iconName, onClick) => {
            const btn = new St.Button({
                style_class: 'healthpanel-control-button',
                can_focus: true,
                x_expand: true,
            });
            const row = new St.BoxLayout({style_class: 'healthpanel-kv'});
            row.add_child(new St.Icon({icon_name: iconName, icon_size: 16}));
            row.add_child(new St.Label({
                text: this._tr(label),
                x_expand: true,
                y_align: Clutter.ActorAlign.CENTER,
            }));
            btn.set_child(row);
            btn.connect('clicked', () => {
                this.menu.close();
                onClick();
            });
            box.add_child(btn);
        };

        // The Plasma widget opens systemsettings and plasma-systemmonitor; the
        // GNOME equivalents are Settings and either Usage or the classic monitor,
        // whichever the system actually has.
        add('System settings', 'preferences-system-symbolic',
            () => this._launch(['gnome-control-center']));
        // NICHT "utilities-system-monitor-symbolic": klingt richtig, gibt es
        // unter Adwaita aber nicht — und ein fehlendes Symbol wird lautlos zum
        // leeren Kasten. Von tools/icons_test.js gefangen.
        add('System monitor', 'org.gnome.SystemMonitor-symbolic',
            () => this._launch(['gnome-system-monitor'], ['gnome-usage']));
    }

    _launch(primary, fallback = null) {
        try {
            Gio.Subprocess.new(primary, Gio.SubprocessFlags.NONE);
        } catch {
            if (fallback) {
                try {
                    Gio.Subprocess.new(fallback, Gio.SubprocessFlags.NONE);
                } catch (e) {
                    logError(e, 'HealthPanel: could not launch a system monitor');
                }
            }
        }
    }

    // ---- refresh ------------------------------------------------------------

    _refresh() {
        if (!this._built || !this._collector)
            return;
        const s = this._collector.system;
        const b = this._collector.battery;

        this._refreshPanel(b, s);
        this._refreshSystem(s);
        this._refreshBattery(b);
        this._refreshProfiles();
        this._syncControls();
    }

    _syncControls() {
        if (!this._built || !this._controls || !this._controlRows)
            return;
        const c = this._controls;
        const set = (key, percent) => {
            const r = this._controlRows[key];
            if (!r || !r.slider)
                return;
            r.slider.value = Math.max(0, Math.min(1, percent / 100));
            r.value.text = `${Math.round(percent)} %`;
        };
        set('screen', c.screen.percent);
        set('keyboard', c.keyboard.percent);
        set('volume', c.volume.percent);
        if (this._controlRows.mute) {
            this._controlRows.mute.row.child.icon_name = c.volume.muted
                ? 'audio-volume-muted-symbolic' : 'audio-volume-high-symbolic';
        }
        if (this._controlRows.inhibit) {
            // Der Zustand steckt in der Hervorhebung, nicht im Text: ein Knopf,
            // dessen Beschriftung zwischen Ursache und Wirkung wechselt, ist
            // jedes Mal neu zu lesen.
            if (c.inhibited)
                this._controlRows.inhibit.row.add_style_class_name('healthpanel-active');
            else
                this._controlRows.inhibit.row.remove_style_class_name('healthpanel-active');
        }
    }

    _refreshSystem(s) {
        const row = id => this._rows.get(id);
        const set = (id, pct, text, color = null) => {
            const r = row(id);
            if (!r)
                return;
            const missing = pct === null;
            r.visible = !missing;
            if (!missing)
                r.update(pct, text, color);
        };

        if (!s.valid) {
            for (const r of this._rows.values())
                r.update(0, '—');
            return;
        }

        set('cpuPct', s.cpuPct, `${s.cpuPct.toFixed(0)} %`);
        set('cpuTemp', s.cpuTempC ? Math.min(100, s.cpuTempC) : null,
            s.cpuTempC ? `${s.cpuTempC.toFixed(0)} °C` : '');
        set('cpuPower', s.cpuPowerW ? Math.min(100, s.cpuPowerW * 2) : null,
            s.cpuPowerW ? `${s.cpuPowerW.toFixed(1)} W` : '');

        set('gpuBusy', s.gpuValid ? s.gpuBusy : null,
            s.gpuValid ? `${s.gpuBusy.toFixed(0)} %` : '');
        set('vram', s.gpuValid && s.vramTotalGB > 0 ? s.vramPct : null,
            s.gpuValid && s.vramTotalGB > 0
                ? `${gb(s.vramUsedGB)} / ${gb(s.vramTotalGB)}` : '');
        set('gpuTemp', s.gpuTempC ? Math.min(100, s.gpuTempC) : null,
            s.gpuTempC ? `${s.gpuTempC.toFixed(0)} °C` : '');

        set('ram', s.ramPct, `${gb(s.ramUsedGB)} / ${gb(s.ramTotalGB)}`);
        set('swap', s.swapTotalGB > 0 ? s.swapPct : null,
            s.swapTotalGB > 0 ? `${gb(s.swapUsedGB)} / ${gb(s.swapTotalGB)}` : '');

        set('disk', s.diskPct, `${gb(s.diskUsedGB)} / ${gb(s.diskTotalGB)}`);
        set('diskIo', Math.min(100, (s.diskReadMBps + s.diskWriteMBps) * 2),
            `↓${s.diskReadMBps.toFixed(1)} ↑${s.diskWriteMBps.toFixed(1)} MB/s`);
        set('diskTemp', s.diskTempC ? Math.min(100, s.diskTempC) : null,
            s.diskTempC ? `${s.diskTempC.toFixed(0)} °C` : '');

        const fans = s.fanRpms ?? [];
        set('fans', fans.length ? Math.min(100, (s.fanMaxRpm / 5000) * 100) : null,
            fans.length ? `${fans.join(' / ')} rpm` : '');

        set('net', Math.min(100, (s.netDownMBps + s.netUpMBps) * 10),
            `↓${s.netDownMBps.toFixed(2)} ↑${s.netUpMBps.toFixed(2)} MB/s`);
    }

    _refreshBattery(b) {
        if (!b.present) {
            this._chargeLabel.text = this._tr('No battery');
            this._chargeBar.setValue(null);
            for (const {row} of this._batRows.values())
                row.hide();
            return;
        }

        const hours = Bat.timeRemainingHours(b);
        const glyph = Bat.statusGlyph(b.status);
        this._chargeLabel.text = `${glyph} ${b.capacityPct}%` +
            (hours > 0 ? `  ·  ${Bat.fmtDuration(hours)}` : '');
        this._chargeBar.setValue(b.capacityPct,
            hexToRgb(Bat.chargeColor(b.status, b.capacityPct)));

        const show = (id, text, visible = true) => {
            const entry = this._batRows.get(id);
            if (!entry)
                return;
            entry.row.visible = visible && text !== '';
            entry.val.text = text;
        };

        show('cycles', b.cycleCount > 0 ? `${b.cycleCount}` : '');
        show('capacity',
            `${Bat.fmtWh(b.energyFullWh)} / ${Bat.fmtWh(b.energyFullDesignWh)}` +
            ` (${Bat.fmtPct(b.healthPct)})`);
        show('status', b.status);
        show('power', b.hasPowerNow ? Bat.fmtW(b.powerNowW) : '');
        show('voltage', Bat.fmtV(b.voltageNowV));
        show('time', hours > 0 ? Bat.fmtDuration(hours) : '');
        show('serial', b.serial);
        show('chargeLimit',
            b.hasChargeThreshold ? `${b.chargeStart}–${b.chargeEnd} %` : '');
    }

    _refreshProfiles() {
        if (!this._profileButtons)
            return;
        const active = this._collector.profile.active;
        for (const [name, btn] of this._profileButtons) {
            if (name === active)
                btn.add_style_class_name('healthpanel-profile-active');
            else
                btn.remove_style_class_name('healthpanel-profile-active');
        }
    }
});

function hexToRgb(hex) {
    const n = parseInt(hex.replace('#', ''), 16);
    return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255];
}

export default class HealthPanelExtension extends Extension {
    enable() {
        this._indicator = new HealthPanelIndicator(this);
        Main.panel.addToStatusArea(this.uuid, this._indicator, 0, 'right');
    }

    disable() {
        this._indicator?.destroy();
        this._indicator = null;
    }
}
