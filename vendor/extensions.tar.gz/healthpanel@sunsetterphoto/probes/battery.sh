#!/usr/bin/env bash
# Battery probe — the first battery's uevent plus the optional charge-control
# files, for BatteryData.applyRawOutput()/sysparse.
#
# Transcribed from the Plasma widget's _probeCmd (main.qml). Missing files become
# empty HP_* values, which the parser reads as "not supported" (Lenovo-style
# charge thresholds are absent on most machines).
export LC_NUMERIC=C

B=$(for d in /sys/class/power_supply/*; do
    [ "$(cat "$d/type" 2>/dev/null)" = Battery ] && echo "$d" && break
done)

[ -n "$B" ] && cat "$B/uevent" 2>/dev/null

echo "HP_CHARGE_START=$(cat "$B/charge_control_start_threshold" 2>/dev/null)"
echo "HP_CHARGE_END=$(cat "$B/charge_control_end_threshold" 2>/dev/null)"
echo "HP_CHARGE_BEHAVIOUR=$(cat "$B/charge_behaviour" 2>/dev/null)"
