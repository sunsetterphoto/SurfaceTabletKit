// Settings window — the port of the plasmoid's five config*.qml pages.
//
// The Plasma pages use a custom LayoutGroup with up/down arrows to reorder
// sections. libadwaita has the same idea natively: an AdwActionRow carrying a
// switch plus move buttons, inside an AdwPreferencesGroup. The stored value is
// byte-identical to the Plasma widget's (layoutmeta.serialize), so a config
// copied between the two desktops still makes sense.

import Adw from 'gi://Adw';
import Gio from 'gi://Gio';
import Gtk from 'gi://Gtk';

import {ExtensionPreferences} from
    'resource:///org/gnome/Shell/Extensions/js/extensions/prefs.js';

import * as LayoutMeta from './lib/layoutmeta.js';
import * as PanelMeta from './lib/panelmeta.js';
import * as I18n from './lib/i18n.js';

export default class HealthPanelPrefs extends ExtensionPreferences {
    fillPreferencesWindow(window) {
        const settings = this.getSettings();
        const lang = I18n.resolve(settings.get_string('language'));
        const tr = s => I18n.tr(lang, s);

        window.add(this._generalPage(settings, tr));
        window.add(this._panelPage(settings, tr));
        window.add(this._layoutPage(settings, tr));
    }

    // ---- general ------------------------------------------------------------

    _generalPage(settings, tr) {
        const page = new Adw.PreferencesPage({
            title: tr('General'),
            icon_name: 'preferences-system-symbolic',
        });

        const appearance = new Adw.PreferencesGroup({title: tr('Appearance')});
        page.add(appearance);

        // Ein Stil je Messwert, wie im Plasma-Widget — ein globaler Schalter
        // waere weniger, nicht einfacher: eine Netzwerkrate will einen Verlauf,
        // eine Speicherbelegung einen Balken.
        const styles = ['bar', 'ring', 'sparkline'];
        const styleNames = Gtk.StringList.new([tr('Bar'), tr('Ring'), tr('Sparkline')]);
        for (const [key, label] of [
            ['cpu-style', tr('CPU')], ['gpu-style', tr('GPU')],
            ['vram-style', tr('VRAM')], ['ram-style', tr('RAM')],
            ['disk-style', tr('Disk')], ['net-style', tr('Network')],
        ]) {
            const row = new Adw.ComboRow({title: label, model: styleNames});
            row.selected = Math.max(0, styles.indexOf(settings.get_string(key)));
            row.connect('notify::selected', r => settings.set_string(key, styles[r.selected]));
            appearance.add(row);
        }

        const langRow = new Adw.ComboRow({
            title: tr('Language'),
            model: Gtk.StringList.new([tr('System'), 'Deutsch', 'English']),
        });
        const langs = ['system', 'de', 'en'];
        langRow.selected = Math.max(0, langs.indexOf(settings.get_string('language')));
        langRow.connect('notify::selected', row =>
            settings.set_string('language', langs[row.selected]));
        appearance.add(langRow);

        const panelText = new Adw.SwitchRow({
            title: tr('Show charge in the panel'),
            subtitle: tr('Percentage next to the panel icon'),
        });
        settings.bind('show-panel-text', panelText, 'active',
                      Gio.SettingsBindFlags.DEFAULT);
        appearance.add(panelText);

        const rates = new Adw.PreferencesGroup({
            title: tr('Refresh'),
            description: tr('The popup samples quickly while open; the panel icon ' +
                            'uses the slower rate the rest of the time, which is ' +
                            'what keeps this cheap on battery.'),
        });
        page.add(rates);

        rates.add(this._spin(settings, 'refresh-seconds', tr('While open'), 1, 60, tr('s')));
        rates.add(this._spin(settings, 'idle-refresh-seconds', tr('While closed'), 5, 600, tr('s')));

        return page;
    }

    _spin(settings, key, title, min, max, unit) {
        const row = new Adw.SpinRow({
            title,
            subtitle: unit,
            adjustment: new Gtk.Adjustment({
                lower: min, upper: max, step_increment: 1, page_increment: 5,
            }),
        });
        settings.bind(key, row, 'value', Gio.SettingsBindFlags.DEFAULT);
        return row;
    }

    // ---- panel icons --------------------------------------------------------

    /**
     * Die Symbole in der Leiste — das Gegenstueck zu configPanel.qml.
     *
     * Ein AdwExpanderRow je Symbol: die Ueberschrift traegt Typ und
     * Reihenfolge, aufgeklappt stehen darin die Werte zum Ankreuzen. Das ist
     * die libadwaita-Entsprechung der Karten im Plasma-Dialog und hat denselben
     * Vorteil — man sieht die Liste als Ganzes, ohne jede Karte offen zu haben.
     *
     * Gespeichert wird byteweise dasselbe JSON wie im Widget, damit eine
     * Konfiguration zwischen beiden Desktops kopiert werden kann.
     */
    _panelPage(settings, tr) {
        const page = new Adw.PreferencesPage({
            title: tr('Panel'),
            icon_name: 'view-reveal-symbolic',
        });

        const types = PanelMeta.types();
        const typeNames = Gtk.StringList.new(types.map(t => tr(t.label)));

        const group = new Adw.PreferencesGroup({
            title: tr('Panel icons'),
            description: tr('Each icon can carry one or more values. ' +
                            'A value its hardware does not report stays empty ' +
                            'instead of showing a zero.'),
        });
        page.add(group);

        let rows = [];
        const read = () => PanelMeta.parseLayout(settings.get_string('panel-layout'));
        const store = items =>
            settings.set_string('panel-layout', PanelMeta.serialize(items));

        const add = new Gtk.Button({
            icon_name: 'list-add-symbolic',
            tooltip_text: tr('Add icon'),
            valign: Gtk.Align.CENTER,
            css_classes: ['flat'],
        });
        add.connect('clicked', () => {
            const items = read();
            items.push({type: 'cpu', texts: ['load']});
            store(items);
            rebuild();
        });
        group.set_header_suffix(add);

        const rebuild = () => {
            for (const r of rows)
                group.remove(r);
            rows = [];

            const items = read();
            items.forEach((item, index) => {
                const meta = PanelMeta.typeMeta(item.type);
                const chosen = Array.isArray(item.texts) ? item.texts : [];
                const row = new Adw.ExpanderRow({
                    title: tr(meta.label),
                    subtitle: chosen.length
                        ? chosen.map(k => tr(PanelMeta.textLabel(item.type, k))).join(', ')
                        : tr('Icon only'),
                });

                const up = new Gtk.Button({
                    icon_name: 'go-up-symbolic',
                    valign: Gtk.Align.CENTER,
                    css_classes: ['flat'],
                    sensitive: index > 0,
                });
                up.connect('clicked', () => {
                    const a = read();
                    [a[index - 1], a[index]] = [a[index], a[index - 1]];
                    store(a);
                    rebuild();
                });
                row.add_suffix(up);

                const down = new Gtk.Button({
                    icon_name: 'go-down-symbolic',
                    valign: Gtk.Align.CENTER,
                    css_classes: ['flat'],
                    sensitive: index < items.length - 1,
                });
                down.connect('clicked', () => {
                    const a = read();
                    [a[index + 1], a[index]] = [a[index], a[index + 1]];
                    store(a);
                    rebuild();
                });
                row.add_suffix(down);

                const remove = new Gtk.Button({
                    icon_name: 'list-remove-symbolic',
                    valign: Gtk.Align.CENTER,
                    css_classes: ['flat'],
                    // Die letzte Zeile bleibt: eine leere Leiste liesse einen
                    // unsichtbaren Knopf zurueck, den niemand mehr findet.
                    sensitive: items.length > 1,
                    tooltip_text: tr('Remove icon'),
                });
                remove.connect('clicked', () => {
                    const a = read();
                    a.splice(index, 1);
                    store(a);
                    rebuild();
                });
                row.add_suffix(remove);

                // Typ wechseln: die gewaehlten Werte gehoeren zum alten Typ und
                // ergeben beim neuen keinen Sinn — also auf dessen ersten Wert.
                const typeRow = new Adw.ComboRow({
                    title: tr('Type'),
                    model: typeNames,
                    selected: Math.max(0, types.findIndex(t => t.type === item.type)),
                });
                typeRow.connect('notify::selected', r => {
                    const next = types[r.selected];
                    if (!next || next.type === item.type)
                        return;
                    const a = read();
                    a[index] = {type: next.type, texts: [next.texts[0].k]};
                    if (item.icon === false)
                        a[index].icon = false;
                    store(a);
                    rebuild();
                });
                row.add_row(typeRow);

                const iconRow = new Adw.SwitchRow({
                    title: tr('Show icon'),
                    subtitle: tr('Off shows the values without an icon'),
                    active: item.icon !== false,
                });
                iconRow.connect('notify::active', sw => {
                    const a = read();
                    if (sw.active)
                        delete a[index].icon;
                    else
                        a[index].icon = false;
                    store(a);
                    rebuild();
                });
                row.add_row(iconRow);

                for (const text of meta.texts) {
                    const valueRow = new Adw.SwitchRow({
                        title: tr(text.l),
                        active: chosen.includes(text.k),
                    });
                    valueRow.connect('notify::active', sw => {
                        const a = read();
                        const list = Array.isArray(a[index].texts) ? a[index].texts : [];
                        // Reihenfolge aus panelmeta.js beibehalten statt nach
                        // Klickreihenfolge: sonst haengt die Anzeige davon ab,
                        // in welcher Reihenfolge man die Haken gesetzt hat.
                        a[index].texts = sw.active
                            ? meta.texts.map(t => t.k)
                                .filter(k => k === text.k || list.includes(k))
                            : list.filter(k => k !== text.k);
                        store(a);
                        rebuild();
                    });
                    row.add_row(valueRow);
                }

                group.add(row);
                rows.push(row);
            });
        };

        rebuild();
        return page;
    }

    // ---- layout -------------------------------------------------------------

    _layoutPage(settings, tr) {
        const page = new Adw.PreferencesPage({
            title: tr('Layout'),
            icon_name: 'view-list-symbolic',
        });

        page.add(this._orderGroup(settings, tr, 'column-order',
            LayoutMeta.columns(), tr('Columns')));
        page.add(this._orderGroup(settings, tr, 'system-order',
            LayoutMeta.systemSections(), tr('System sections')));
        page.add(this._orderGroup(settings, tr, 'battery-order',
            LayoutMeta.batteryBlocks(), tr('Battery details')));

        return page;
    }

    /** One reorderable, toggleable list bound to a JSON order key. */
    _orderGroup(settings, tr, key, meta, title) {
        const group = new Adw.PreferencesGroup({title});
        const labels = new Map(meta.map(m => [m.id, m.label]));

        const reset = new Gtk.Button({
            icon_name: 'edit-undo-symbolic',
            tooltip_text: tr('Reset'),
            valign: Gtk.Align.CENTER,
            css_classes: ['flat'],
        });
        reset.connect('clicked', () => {
            settings.set_string(key, LayoutMeta.serialize(LayoutMeta.defaultOrder(meta)));
            rebuild();
        });
        group.set_header_suffix(reset);

        let rows = [];

        const store = order => settings.set_string(key, LayoutMeta.serialize(order));

        const rebuild = () => {
            for (const r of rows)
                group.remove(r);
            rows = [];

            const order = LayoutMeta.parseOrder(settings.get_string(key), meta);

            order.forEach((entry, index) => {
                const row = new Adw.ActionRow({
                    title: tr(labels.get(entry.id) ?? entry.id),
                });

                const up = new Gtk.Button({
                    icon_name: 'go-up-symbolic',
                    valign: Gtk.Align.CENTER,
                    css_classes: ['flat'],
                    sensitive: index > 0,
                });
                up.connect('clicked', () => {
                    const o = LayoutMeta.parseOrder(settings.get_string(key), meta);
                    [o[index - 1], o[index]] = [o[index], o[index - 1]];
                    store(o);
                    rebuild();
                });

                const down = new Gtk.Button({
                    icon_name: 'go-down-symbolic',
                    valign: Gtk.Align.CENTER,
                    css_classes: ['flat'],
                    sensitive: index < order.length - 1,
                });
                down.connect('clicked', () => {
                    const o = LayoutMeta.parseOrder(settings.get_string(key), meta);
                    [o[index + 1], o[index]] = [o[index], o[index + 1]];
                    store(o);
                    rebuild();
                });

                const toggle = new Gtk.Switch({
                    active: entry.v,
                    valign: Gtk.Align.CENTER,
                });
                toggle.connect('notify::active', sw => {
                    const o = LayoutMeta.parseOrder(settings.get_string(key), meta);
                    o[index].v = sw.active;
                    store(o);
                });

                row.add_suffix(up);
                row.add_suffix(down);
                row.add_suffix(toggle);
                row.activatable_widget = toggle;

                group.add(row);
                rows.push(row);
            });
        };

        rebuild();
        return group;
    }
}
